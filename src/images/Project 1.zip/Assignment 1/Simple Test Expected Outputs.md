***Simple Test Case Solutions***

**Coin**

**BFS**

The plan: ['open door to south', 'move south', 'open door to east', 'move east', 'take coin']
Number of visited states: 30

**DFS**

The plan: ['open door to west', 'open door to south', 'close door to west', 'move south', 'open door to east', 'move north', 'open door to west', 'move south', 'close door to north', 'move east', 'take coin']
Number of visited states: 12

**A-Star**

The plan: ['open door to south', 'move south', 'open door to east', 'move east', 'take coin']
Number of visited states: 15



**Map Reader**

**BFS**

The plan: ['move west', 'move north', 'take coin', 'move south', 'move east', 'put coin in box']
Number of visited states: 19


**DFS**

The plan: ['put map in box', 'move north', 'move west', 'take coin', 'move south', 'move east', 'put coin in box']
Number of visited states: 11


**A-Star**

The plan: ['move north', 'move west', 'take coin', 'move east', 'move south', 'put coin in box']
Number of visited states: 16