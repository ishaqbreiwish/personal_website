
# COPY YOUR "RUN ALL" OUTPUT HERE
dict1 = """

"""

# COPY EXPECTED OUTPUT FOR THE TESTED ALGORITHM HERE
dict2 = """

"""

student_solution = eval(dict1)
expected_solution = eval(dict2)
failed_set = set()
for k in student_solution:

    student_path = student_solution[k][0] 
    expected_path = expected_solution[k][0]
    student_visited_size = len(set(student_solution[k][1]))
    expected_visited_size = len(set(expected_solution[k][1]))
    failed = False
    
    if len(student_path) != len(expected_path):
        failed = True
    if student_visited_size != expected_visited_size:
        print("Visited set sizes differed for " + str(k))
        print("student visited set size: " + str(student_visited_size))
        print("expected visited set size: " + str(expected_visited_size))
    if not failed:
        for i in range(len(student_path)):
            if student_path[i] != expected_path[i] and expected_path[i] in ["take coin", "put coin in box"]:
                failed = True
                break
    if failed:
        print("FAILED")
        print(k)
        print(student_path)
        print(expected_path)
        failed_set.add(k)
    

for k in student_solution:
    if k not in failed_set:
        print("SUCCESS")
        print(k)

